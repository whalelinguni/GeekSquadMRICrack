import os
import re

def clear_console():
    os.system('cls' if os.name == 'nt' else 'clear')

def find_dllcutables_in_dir(directory):
    dll_files = [f for f in os.listdir(directory) if f.endswith('.dll')]
    return dll_files

def get_default_binary_files(script_dir):
    dll_files = find_dllcutables_in_dir(script_dir)
    
    if len(dll_files) < 2:
        return None, None  # Not enough .dll files to compare

    variant_binaries = []
    base_binaries = []

    for dll in dll_files:
        if re.search(r'orig|bak|copy|new', dll, re.IGNORECASE):
            variant_binaries.append(dll)
        else:
            base_binaries.append(dll)

    if not variant_binaries or not base_binaries:
        return None, None  # Couldn't find a match

    best_match = None
    best_score = -1

    for variant in variant_binaries:
        variant_base_name = re.sub(r'(orig|bak|copy|new)', '', variant, flags=re.IGNORECASE)
        variant_base_name = re.sub(r'\.dll$', '', variant_base_name, flags=re.IGNORECASE)

        for base in base_binaries:
            base_name = re.sub(r'\.dll$', '', base, flags=re.IGNORECASE)
            match_length = len(os.path.commonprefix([variant_base_name, base_name]))

            if match_length > best_score:
                best_score = match_length
                best_match = (variant, base)

    return best_match

def read_binary_file(filepath):
    with open(filepath, 'rb') as f:
        return f.read()

def compare_files(file1, file2):
    bytes1 = read_binary_file(file1)
    bytes2 = read_binary_file(file2)
    
    max_len = min(len(bytes1), len(bytes2))
    differences = []
    
    for i in range(max_len):
        if bytes1[i] != bytes2[i]:
            differences.append({
                'Offset': f'0x{i:08X}',
                'File1 (Byte)': f'0x{bytes1[i]:02X}',
                'File2 (Byte)': f'0x{bytes2[i]:02X}'
            })

    if len(bytes1) != len(bytes2):
        for i in range(max_len, max(len(bytes1), len(bytes2))):
            if i < len(bytes1):
                differences.append({
                    'Offset': f'0x{i:08X}',
                    'File1 (Byte)': f'0x{bytes1[i]:02X}',
                    'File2 (Byte)': 'N/A'
                })
            else:
                differences.append({
                    'Offset': f'0x{i:08X}',
                    'File1 (Byte)': 'N/A',
                    'File2 (Byte)': f'0x{bytes2[i]:02X}'
                })

    return differences

def save_differences_console_style(differences, file1, file2):
    file1_name = os.path.basename(file1)
    file2_name = os.path.basename(file2)

    # Suggest a default filename for saving the differences
    default_filename = f"{os.path.splitext(file1_name)[0]}_{os.path.splitext(file2_name)[0]}_diff.wpDiff"
    output_filename = input(f"Enter the filename to save the differences [{default_filename}]: ").strip() or default_filename

    with open(output_filename, 'w') as f:
        f.write(f'File 1: {file1_name}\n')
        f.write(f'File 2: {file2_name}\n\n')
        f.write(f'Differences between {file1_name} and {file2_name}:\n')
        f.write(f"{'Offset':<12} {file1_name:<20} {file2_name:<20}\n")
        f.write(f"{'-'*12} {'-'*20} {'-'*20}\n")
        for diff in differences:
            f.write(f"{diff['Offset']:<12} {diff['File1 (Byte)']:<20} {diff['File2 (Byte)']:<20}\n")
    
    print(f"\nResults saved to: {output_filename}")

def generate_patch_script(differences, file1, file2, patch_from):
    file1_name = os.path.basename(file1)
    file2_name = os.path.basename(file2)
    
    # Suggest a default filename for the patch script
    default_patch_filename = f"{os.path.splitext(file1_name if patch_from == '1' else file2_name)[0]}-patcher.py"
    output_filename = input(f"Enter the filename to save the patch script [{default_patch_filename}]: ").strip() or default_patch_filename

    patch_script = f"""
import os

def apply_patch(input_file):
    # Inform the user that patching is starting
    print(f"\\nPatching {{os.path.basename(input_file)}}...")

    # Read the binary file into a bytearray for modification
    with open(input_file, 'r+b') as f:
        file_bytes = bytearray(f.read())

    # List to keep track of patches applied
    patches_applied = []

"""
    file_from = "File1 (Byte)" if patch_from == "1" else "File2 (Byte)"
    for diff in differences:
        byte_value = diff[file_from].replace("0x", "")
        offset = int(diff['Offset'], 16)
        patch_script += f"""
    # Applying patch at offset {diff['Offset']}
    original_byte = file_bytes[{offset}]
    new_byte = 0x{byte_value}
    file_bytes[{offset}] = new_byte
    patches_applied.append((hex({offset}), hex(original_byte), hex(new_byte)))
    print(f"Patched offset {{hex({offset})}}: original byte {{hex(original_byte)}} -> new byte {{hex(new_byte)}}")"""
    
    patch_script += """
    
    # Write the patched bytes back to the file
    with open(input_file, 'wb') as f:
        f.write(file_bytes)

    # Confirm to the user that patching is complete and list all patches
    print(f"\\nPatching of {{os.path.basename(input_file)}} completed successfully.")
    print("\\nThe following changes were made:")
    for patch in patches_applied:
        print(f"Offset {{patch[0]}}: {{patch[1]}} -> {{patch[2]}}")
    print(f"\\nYou can now use the patched file: {{input_file}}")

if __name__ == "__main__":
    # Prompt the user to enter the path to the binary file to patch
    input_file = input("Enter the path to the binary file to patch: ").strip()
    if os.path.exists(input_file):
        apply_patch(input_file)
    else:
        print(f"Error: The file {{input_file}} does not exist. Please check the path and try again.")
"""

    with open(output_filename, 'w') as f:
        f.write(patch_script)

    print(f"\nPatch script saved to: {output_filename}")


def create_patch_script(differences, file1, file2):
    if differences:
        print(f"\nWhich file do you want to generate the patch for?\n1. {os.path.basename(file1)}\n2. {os.path.basename(file2)}")
        patch_from = input("Enter the number (1 or 2): ").strip()
        generate_patch_script(differences, file1, file2, patch_from)
    else:
        print("\nNo differences found. No patch script will be generated.")


def generate_patch_process(script_dir):
    match = get_default_binary_files(script_dir)

    if not match or match == (None, None):
        print("Not enough .exe files found to compare.")
        # Proceed without auto-setting defaults, let the user manually enter the paths
        file1 = input("Enter the path to the first binary file: ").strip()
        file2 = input("Enter the path to the second binary file: ").strip()
    else:
        binary1, binary2 = match
        binary1_path = os.path.join(script_dir, binary1)
        binary2_path = os.path.join(script_dir, binary2)

        print(f"\nDefault Binary 1: {binary1}")
        print(f"Default Binary 2: {binary2}")

        # If auto-detection works, use auto-detected paths but allow for manual input
        file1 = input(f"Enter the path to the first binary file [{binary1}]: ").strip() or binary1_path
        file2 = input(f"Enter the path to the second binary file [{binary2}]: ").strip() or binary2_path

    # Extracting file names for display
    file1_name = os.path.basename(file1)
    file2_name = os.path.basename(file2)

    print(f"\nFile 1: {file1_name}")
    print(f"File 2: {file2_name}\n")

    # Compare the files
    differences = compare_files(file1, file2)

    if differences:
        print("\nDifferences found:")
        print(f"{'Offset':<12} {file1_name:<20} {file2_name:<20}")
        print(f"{'-'*12} {'-'*20} {'-'*20}\n")
        for diff in differences:
            print(f"{diff['Offset']:<12} {diff['File1 (Byte)']:<20} {diff['File2 (Byte)']:<20}")
        
        save_results = input("\nDo you want to save the differences? (y/n): ").strip().lower()
        if save_results == 'y':
            save_differences_console_style(differences, file1, file2)
        else:
            print("\nResults were not saved.")
        
        generate_patch = input("\nDo you want to generate a patch script from these differences? (y/n): ").strip().lower()
        if generate_patch == 'y':
            create_patch_script(differences, file1, file2)
        else:
            print("\nPatch script was not generated.")
    else:
        print("\nThe files are identical.")



def load_save_file():
    save_file_path = input("Enter the path to the saved file: ").strip()

    if not os.path.exists(save_file_path):
        print("Error: The specified save file does not exist.")
        return

    with open(save_file_path, 'r') as f:
        lines = f.readlines()

    file1 = file2 = None
    differences = []

    for line in lines:
        if line.startswith("File 1:"):
            file1 = line.split(":")[1].strip()
        elif line.startswith("File 2:"):
            file2 = line.split(":")[1].strip()
        elif line.startswith("0x"):
            parts = line.split()
            offset = parts[0]
            byte1 = parts[1]
            byte2 = parts[2]
            differences.append({
                'Offset': offset,
                'File1 (Byte)': byte1,
                'File2 (Byte)': byte2
            })

    if file1 and file2:
        print("\nLoaded Save File Content:")
        print(f"File 1: {file1}")
        print(f"File 2: {file2}\n")
        print(f"Differences between {file1} and {file2}:\n")
        print(f"{'Offset':<12} {file1:<20} {file2:<20}")
        print(f"{'-'*12} {'-'*20} {'-'*20}\n")
        for diff in differences:
            print(f"{diff['Offset']:<12} {diff['File1 (Byte)']:<20} {diff['File2 (Byte)']:<20}")

        generate_patch = input("\nDo you want to generate a patch script from these differences? (y/n): ").strip().lower()
        if generate_patch == 'y':
            create_patch_script(differences, file1, file2)
        else:
            print("\nPatch script was not generated.")
    else:
        print("Error: The save file is not in the expected format.")

def show_splash():
    print(r"  __      __.__           .__           __________         __         .__                  ")
    print(r" /  \    /  \  |__ _____  |  |   ____   \______   \_____ _/  |_  ____ |  |__   ___________ ")
    print(r"\\   \/\/   /  |  \\__  \ |  | _/ __ \   |     ___/\__  \\   __\/ ___\|  |  \_/ __ \_  __ \\")
    print(r" \\        /|   Y  \/ __ \|  |_\  ___/   |    |     / __ \|  | \  \___|   Y  \  ___/|  | \/")
    print(r"  \\__/\  / |___|  (____  /____/\___  >  |____|    (____  /__|  \___  >___|  /\___  >__|   ")
    print(r"        \/       \/     \/          \/                  \/          \/     \/     \/       ")

def show_menu():
    clear_console()
    show_splash()
    script_dir = os.path.dirname(os.path.realpath(__file__))
    while True:
        print("\nMenu:")
        print("1. Generate Patch Script")
        print("2. Load Diff Save")
        print("3. Exit")
        choice = input("Enter your choice: ").strip()

        if choice == '1':
            generate_patch_process(script_dir)
        elif choice == '2':
            load_save_file()
        elif choice == '3':
            print("Exiting...")
            break
        else:
            print("Invalid choice. Please select a valid option.")

if __name__ == "__main__":
    show_menu()
