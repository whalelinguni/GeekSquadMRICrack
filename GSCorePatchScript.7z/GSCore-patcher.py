
import os

def apply_patch(input_file):
    # Inform the user that patching is starting
    print(f"\nPatching {os.path.basename(input_file)}...")

    # Read the binary file into a bytearray for modification
    with open(input_file, 'r+b') as f:
        file_bytes = bytearray(f.read())

    # List to keep track of patches applied
    patches_applied = []


    # Applying patch at offset 0x00009921
    original_byte = file_bytes[39201]
    new_byte = 0x90
    file_bytes[39201] = new_byte
    patches_applied.append((hex(39201), hex(original_byte), hex(new_byte)))
    print(f"Patched offset {hex(39201)}: original byte {hex(original_byte)} -> new byte {hex(new_byte)}")
    # Applying patch at offset 0x00009922
    original_byte = file_bytes[39202]
    new_byte = 0x90
    file_bytes[39202] = new_byte
    patches_applied.append((hex(39202), hex(original_byte), hex(new_byte)))
    print(f"Patched offset {hex(39202)}: original byte {hex(original_byte)} -> new byte {hex(new_byte)}")
    # Applying patch at offset 0x00009923
    original_byte = file_bytes[39203]
    new_byte = 0x90
    file_bytes[39203] = new_byte
    patches_applied.append((hex(39203), hex(original_byte), hex(new_byte)))
    print(f"Patched offset {hex(39203)}: original byte {hex(original_byte)} -> new byte {hex(new_byte)}")
    # Applying patch at offset 0x00009924
    original_byte = file_bytes[39204]
    new_byte = 0x90
    file_bytes[39204] = new_byte
    patches_applied.append((hex(39204), hex(original_byte), hex(new_byte)))
    print(f"Patched offset {hex(39204)}: original byte {hex(original_byte)} -> new byte {hex(new_byte)}")
    # Applying patch at offset 0x00009925
    original_byte = file_bytes[39205]
    new_byte = 0x90
    file_bytes[39205] = new_byte
    patches_applied.append((hex(39205), hex(original_byte), hex(new_byte)))
    print(f"Patched offset {hex(39205)}: original byte {hex(original_byte)} -> new byte {hex(new_byte)}")
    # Applying patch at offset 0x00009926
    original_byte = file_bytes[39206]
    new_byte = 0x90
    file_bytes[39206] = new_byte
    patches_applied.append((hex(39206), hex(original_byte), hex(new_byte)))
    print(f"Patched offset {hex(39206)}: original byte {hex(original_byte)} -> new byte {hex(new_byte)}")
    
    # Write the patched bytes back to the file
    with open(input_file, 'wb') as f:
        f.write(file_bytes)

    # Confirm to the user that patching is complete and list all patches
    print(f"\nPatching of {{os.path.basename(input_file)}} completed successfully.")
    print("\nThe following changes were made:")
    for patch in patches_applied:
        print(f"Offset {{patch[0]}}: {{patch[1]}} -> {{patch[2]}}")
    print(f"\nYou can now use the patched file: {{input_file}}")

if __name__ == "__main__":
    # Prompt the user to enter the path to the binary file to patch
    input_file = input("Enter the path to the binary file to patch: ").strip()
    if os.path.exists(input_file):
        apply_patch(input_file)
    else:
        print(f"Error: The file {{input_file}} does not exist. Please check the path and try again.")
