
# GSCommon.dll Date Patch Script

This repository contains a Python script designed to patch the `GSCommon.dll` file to ensure that the associated program runs correctly by applying a date patch. The script changes a specific byte in the DLL to modify the program's behavior, allowing it to function as intended.

## Overview

The `GSCommon.dll` file is a critical component of a software program. Due to a date-related issue, the program may fail to run properly. This patch script addresses the issue by changing a single byte in the DLL file.

### What the Script Does

- **Target File:** `GSCommon.dll`
- **Original Byte:** `0x74`
- **Patched Byte:** `0x75`
- **Offset:** `0x2DA11`

The script reads the `GSCommon.dll` file, checks the byte at the specified offset, and modifies it if necessary. This change allows the program to bypass the date issue and run correctly.

## Usage

### Prerequisites

- **Python 3.x** installed on your system.

### Instructions

1. **Clone the repository:**

   ```bash
   git clone https://github.com/your-username/gscommon-date-patch.git
   cd gscommon-date-patch
   ```

2. **Place the DLL file:**

   Ensure that the `GSCommon.dll` file you want to patch is in the same directory as the script.

3. **Run the patch script:**

   ```bash
   python patch_gscommon.py
   ```

4. **Verify the output:**

   The script will output messages indicating the success or failure of the patch operation. If the byte was successfully patched, the program should now run correctly.

## Troubleshooting

- **Offset Out of Range:** If you encounter an "Offset out of range" error, ensure that the `GSCommon.dll` file is the correct version and that the file size matches expectations.
- **No Byte Change:** If the script indicates that the byte at the specified offset doesn't match the expected value (`0x74`), double-check that the DLL hasn't already been modified.

## Contributing

If you find any issues or have suggestions for improvements, feel free to open an issue or submit a pull request. Contributions are welcome!

## License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.

---

**Disclaimer:** This script is provided as-is, without any warranty. Use it at your own risk. Make sure to back up your original DLL file before applying the patch.
